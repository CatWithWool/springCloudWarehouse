package controller;

import org.springframework.stereotype.Component;

@Component
public class ApiServiceError implements  ApiService {

    @Override
    public String index() {
        return "服务器故障";
    }
}
