package controller;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 *  Hystrix 组件（该组件实现了熔断器模式）
 *  Feign 是默认自带熔断器的，在 D 版本 SpringCloud 中是默认关闭的，我们可以在 application.yml 中开启它
 *  如果服务提供者正常，则接口请求成功，如果失败，则跳转到ApiServiceError.class
 */
@FeignClient(value = "eurekaclient",fallback = ApiServiceError.class)
@Service
public interface ApiService {
    @RequestMapping(value = "/index",method = RequestMethod.GET)
    String index();
}
